x = 1:18;
y1 = 10^6*[3.95,3.37,3.10,2.95,2.85,2.98,2.86,2.92,2.89,2.90,2.895,3.00,2.97,2.93,3.03,3.09,3.11,3.16];
y2 = [98.87,98.929,98.975,99.0,99.008,98.988,98.982,98.961,98.935,98.932,98.930,98.907,98.88,98.866,98.85,98.811,98.792,98.772];
h1 = figure;
left_color = [0 0 0];
right_color = [0 0 0];
set(h1,'defaultAxesColorOrder',[left_color; right_color]);
yyaxis left
plot(x,y2,'b','LineWidth',2);
ylabel('Availability (%)','color','k')
yyaxis right
plot(x,y1,'k','LineWidth',2);
xlabel('Maintenance Interval (Month)')
ylabel('Overall Cost ($)','color','k')

legend('Availability','Overall Cost');
set(gca,'FontSize',16)

print(h1,'airliquide1','-dpng')

h2 = figure;
y30 = 67526;
y40 = 50437;
y31 = 1317527;
y41 = 1350438;
y33 = 2353991;
y43 = 2528579;
y32 = 288713;	
y42 = 430390;

y = [y30,y40; y31,y41;y32,y42;y33,y43];
c = categorical({'Travel cost','Labor cost','Spare part cost','Overall cost'});
c = reordercats(c,{'Travel cost','Labor cost','Spare part cost','Overall cost'});
b = bar(c,y);
legend('Concentrated','Distributed','Location','northwest');
set(gca,'FontSize',16)
ylabel('Cost ($)')
print(h2,'airliquide2','-dpng')

